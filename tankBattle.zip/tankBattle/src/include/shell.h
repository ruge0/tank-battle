#ifndef TANKBATTLE_SHELL_H
#define TANKBATTLE_SHELL_H

class Shell
{
public:
    char mode = '*';
    struct Info
    {
        int id;
        int x;
        int y;
    }info;
    int m_direction;

public:
    Shell(int id, int x, int y, int direction);
    Info* getInfo();
    void shellMove();
    ~Shell();
};

#endif //TANKBATTLE_SHELL_H
