#ifndef TANKBATTLE_NET_H
#define TANKBATTLE_NET_H

#include <string>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/socket.h>
#include <sys/unistd.h>
#include <sys/types.h>
#include <cerrno>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <deque>

#define BUFFSIZE 100
#define SERVER_IP "192.168.10.129"
#define SERVER_PORT 45555

class Net
{
private:
    //申请和释放网络资源的条件变量
    static volatile int netNum;
    //网络套接字
    static int sockfd;
    //网络协议簇
    sockaddr_in servaddr;
    //接收缓冲区
    char m_buff[BUFFSIZE];

public:
    Net();
    //获取网络套接字
    int getScokfd();
    //向服务端发送信息
    int netIn(const char* str);
    int netIn(std::string str);
    //从服务器接收信息
    char* netOut();
    ~Net();
};

#endif //TANKBATTLE_NET_H
