#ifndef TANKBATTLE_TANK_H
#define TANKBATTLE_TANK_H

#include <chrono>
#include <thread>
#include <unistd.h>
using namespace std;
#include "shell.h"

class Tank
{
public:
    bool m_cd;        //开火CD
    int x, y;         //坐标
    int m_direction;  //朝向
    int m_color;      //颜色
    int m_model;      //模型
    int m_id;         //编号
    bool m_survival;   //是否存活

    static const char* tank_figure[4][3][4];

private:
   static pthread_mutex_t pthreadMutex;
   static pthread_cond_t pthreadCoond;
   pthread_t resetId;

public:
    Tank(int id, int model, int color, int x, int y);
    void tankMove();
    Shell* tankFire();
    static void * resetCD(void *ptr);
    ~Tank();
};

#endif //TANKBATTLE_TANK_H
