#ifndef TANKBATTLE_IO_H
#define TANKBATTLE_IO_H

#define MINID 10000

#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <algorithm>
#include <unistd.h>
using namespace std;
#include "map.h"
#include "net.h"
#include "tank.h"
#include "shell.h"

class Io :public Map
{
private:
    //已有的坦克队列
    static vector<Tank*> m_vecTank;
    //已有的炮弹队列
    static vector<Shell*> m_vecShell;
    //访问两个队列的锁
    static pthread_mutex_t pthreadMutexTank;
    static pthread_mutex_t pthreadMutexShell;
    //释放坦克和炮弹内存的条件变量
    static volatile int ioNum;
    //屏幕刷新的线程id
    static pthread_t ioId;
    //网络信息的接收id
    static pthread_t recvId;
    //判断可不可以操作时钟信息
    static volatile int timeSig;

public:
    Tank* myTank;
    Net net;

public:
    Io();
    void Run();
    void addTank(int id, int model, int color, int x, int y);
    void addShell(Tank* tank);
    void addMap(int x, int y, int n);
    void subMap(int x, int y, int n);
    //初始化坦克
    void tankChoice(int id);
    //用户登录
    int printLogin();
    //与服务器断开连接
    void printDropLine();
    //打印队列里所有坦克，2帧一动
    void printTank();
    //打印队列里所有炮弹，1帧一动
    void printShell();
    //清理上一帧打印的炮弹
    void clearShell();
    //坦克碰撞检测
    bool collision(Tank* t);
    //炮弹碰撞检测
    int collision(Shell* s);
    //打印地图
    void printMap();
    //处理网络信息
    static void* netRecv(void* ptr);
    //刷新屏幕信息
    static void* refresh(void* ptr);
    ~Io();
};

#endif //TANKBATTLE_IO_H
