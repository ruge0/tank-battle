#include "net.h"

int Net::sockfd;
volatile int Net::netNum = 0;

Net::Net()
{
    if (!__sync_fetch_and_add(&netNum, 1))
    {
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (-1 == sockfd)
        {
            printf("Create socket error(%d): %s\n", errno, strerror(errno));
            exit(-1);
        }

        bzero(&servaddr, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        inet_pton(AF_INET, SERVER_IP, &servaddr.sin_addr);
        servaddr.sin_port = htons(SERVER_PORT);
        if (-1 == connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)))
        {
            printf("Connect error(%d): %s\n", errno, strerror(errno));
            exit(0);
        }
    }
}

int Net::netIn(const char *str)
{
    return send(sockfd, str, strlen(str), MSG_NOSIGNAL);
}

int Net::netIn(std::string str)
{
    return send(sockfd, &str[0], str.size(), MSG_NOSIGNAL);
}

char* Net::netOut()
{
    bzero(m_buff, BUFFSIZE);
    if (0 == recv(sockfd, m_buff, BUFFSIZE, MSG_NOSIGNAL))
    {
        return nullptr;
    }

    return m_buff;
}

int Net::getScokfd()
{
    return this->sockfd;
}

Net::~Net()
{
    if (!__sync_sub_and_fetch(&netNum, 1))
    {
        close(this->sockfd);
    }
}