#include "tank.h"

pthread_mutex_t Tank::pthreadMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t Tank::pthreadCoond = PTHREAD_COND_INITIALIZER;
const char* Tank::tank_figure[4][3][4] =
        {
                {
                        {"◢┃◣", "◢━◣", "◢┳◣", "◢┳◣"},
                        {"┣●┫", "┣●┫", "━●┃", "┃●━"},
                        {"◥━◤", "◥┃◤", "◥┻◤", "◥┻◤"}
                },
                {
                        {"┏┃┓", "┏┳┓", "┏┳┓", "┏┳┓"},
                        {"┣●┫", "┣●┫", "━●┫", "┣●━"},
                        {"┗┻┛", "┗┃┛", "┗┻┛", "┗┻┛"}
                },
                {
                        {"┏┃┓", "◢━◣", "┏┳◣", "◢┳┓"},
                        {"┣●┫", "┣●┫", "━●┃", "┃●━"},
                        {"◥━◤", "┗┃┛", "┗┻◤", "◥┻┛"}
                },
                {
                        {"╔┃╗", "╔╦╗", "╔╦╗", "╔╦╗"},
                        {"╠█╣", "╠█╣", "━█╣", "╠█━"},
                        {"╚╩╝", "╚┃╝", "╚╩╝", "╚╩╝"}
                }
        };

Tank::Tank(int id, int model, int color, int x, int y)
{
    this->x = x;
    this->y = y;
    this->m_direction = 0;
    this->m_color = color;
    this->m_model = model;
    this->m_id = id;
    this->m_cd = true;
    this->m_survival = true;
    pthread_create(&resetId, nullptr, resetCD, this);
}

void *Tank::resetCD(void *ptr)
{
    Tank* ta = (Tank*) ptr;
    while (true)
    {
        pthread_mutex_lock(&pthreadMutex);
        while (ta->m_cd)
        {
            pthread_cond_wait(&pthreadCoond,&pthreadMutex);
        }
        pthread_mutex_unlock(&pthreadMutex);

        sleep(2);

        ta->m_cd = true;
    }
}

Shell *Tank::tankFire()
{
    if (!this->m_cd)
    {
        return nullptr;
    }

    this->m_cd = false;
    pthread_cond_signal(&pthreadCoond);

    return (new Shell(this->m_id, this->x, this->y, this->m_direction));
}

void Tank::tankMove()
{
    switch (m_direction)
    {
        case 0:
            (this->y)--;
            break;
        case 1:
            (this->y)++;
            break;
        case 2:
            (this->x) -= 2;
            break;
        case 3:
            (this->x) += 2;
            break;
    }
}

Tank::~Tank()
{
    pthread_cancel(this->m_id);
}
