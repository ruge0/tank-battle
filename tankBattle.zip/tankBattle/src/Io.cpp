#include "Io.h"

vector<Tank*> Io::m_vecTank;
vector<Shell*> Io::m_vecShell;
pthread_mutex_t Io::pthreadMutexTank = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t Io::pthreadMutexShell = PTHREAD_MUTEX_INITIALIZER;
volatile int Io::ioNum = 0;
volatile int Io::timeSig = 0;
pthread_t Io::ioId;
pthread_t Io::recvId;

Io::Io() = default;

void Io::printMap()
{
    for (int i = 0; i < MAPLEN; i++)
    {
        cout << "\033[" << i + 1 << ";0H";

        for (int j = 0; j < MAPLEN; j++)
        {
            switch (map[i][j])
            {
                case 0:
                    cout << "\033[2C";
                    break;
                case 1:
                    cout << "\033[40;31m▓▓\033[0m";
                    break;
                case 5:
                    cout << "\033[44;32m~~\033[0m";
                    break;
                case 6:
                    cout << "\033[40;37m■■\033[0m";
                    break;
                case 4:
                    cout << "～";
                    break;
            }
        }
    }
}

void Io::addTank(int id, int model, int color, int x, int y)
{
    Tank* tank = new Tank(id, model, color, x, y);
    pthread_mutex_lock(&pthreadMutexTank);
    m_vecTank.push_back(tank);
    pthread_mutex_unlock(&pthreadMutexTank);
}

void Io::addShell(Tank* tank)
{
    Shell* shell = tank->tankFire();
    pthread_mutex_lock(&pthreadMutexShell);
    m_vecShell.push_back(shell);
    pthread_mutex_unlock(&pthreadMutexShell);
}

void Io::addMap(int x, int y, int n)
{
    if (n > MINID)
    {
        for (int i = 0; i < 3; i++)
        {
            map[x+i-1][y-1] = n;
            map[x+i-1][y] = n;
            map[x+i-1][y+1] = n;
        }
    }
    else
    {
        map[x][y] = n;
    }
}

void Io::subMap(int x, int y, int n)
{
    if (n > MINID)
    {
        for (int i = 0; i < 3; i++)
        {
            map[x+i-1][y-1] = 0;
            map[x+i-1][y] = 0;
            map[x+i-1][y+1] = 0;
        }
    }
    else
    {
        map[x][y] = 0;
    }
}

void Io::printTank()
{
    for (Tank* t : m_vecTank)
    {
        if (!t->m_survival)
        {
            continue;
        }
        for (int i = 0; i < 3; i++)
        {
            cout << "\033[" << t->y + i - 1 << ';' << t->x - 1 << 'H';
            cout << "\033[40;" << t->m_color << 'm';
            cout << (Tank::tank_figure[t->m_model][i][t->m_direction]);
            cout << "\033[0m";
        }
    }
}

void Io::printShell()
{
    for (Shell* s : m_vecShell)
    {
        cout << "\033[" << s->info.y << ';' << s->info.x << 'H';
        cout << "\033[0m" << s->mode;
    }
}

void Io::clearShell()
{
    for (Shell* s : m_vecShell)
    {
        cout << "\033[" << s->info.y << ';' << s->info.x << 'H';
        cout << "\033[40;30m" << s->mode;
    }
}

bool Io::collision(Tank *t)
{
    int i = t->x - 1;
    int j = t->y - 1;
    int stopi = i + 2;
    int stopj = j + 2;

    while (i > stopi)
    {
        while (j > stopj)
        {
            if (map[i][j] != 0 && map[i][j] != 5)
            {
                return false;
            }
            j++;
        }
        i++;
    }

    return true;
}

int Io::collision(Shell *s)
{
    int x = map[s->info.x][s->info.y];
    auto info = find(m_vecShell.begin(), m_vecShell.end(), s);

    if (x > MINID)
    {
        for (Tank* t : m_vecTank)
        {
            if (t->m_id == x)
            {
                t->m_survival = false;
                subMap(s->info.x, s->info.y, s->info.id);
                pthread_mutex_lock(&pthreadMutexShell);
                m_vecShell.erase(info);
                pthread_mutex_unlock(&pthreadMutexShell);
                net.netIn("Die:" + to_string(t->m_id));
                return x;
            }
        }
    }

    switch (x)
    {
        case 1:
            map[s->info.x][s->info.y] = 0;
            pthread_mutex_lock(&pthreadMutexShell);
            m_vecShell.erase(info);
            pthread_mutex_unlock(&pthreadMutexShell);
            return 1;
        case 4:
            pthread_mutex_lock(&pthreadMutexShell);
            m_vecShell.erase(info);
            pthread_mutex_unlock(&pthreadMutexShell);
            return 4;
        case 6:
            pthread_mutex_lock(&pthreadMutexShell);
            m_vecShell.erase(info);
            pthread_mutex_unlock(&pthreadMutexShell);
            return 6;
        default:
            return 0;
    }
}

void *Io::refresh(void *ptr)
{
    Io* io = (Io*) ptr;

    while (true)
    {
        cout << "\033[2J";
        io->printMap();
        io->printTank();
        for (Shell* s : m_vecShell)
        {
            io->collision(s);
        }
        io->printShell();

        __sync_bool_compare_and_swap(&timeSig, 0, 1);
        cout << "\033[42;15H" << "指令： " << flush;
        usleep(200000);
        __sync_bool_compare_and_swap(&timeSig, 1, 0);

        io->clearShell();
        for (Shell* s : m_vecShell)
        {
            s->shellMove();
            io->collision(s);
        }
        io->printShell();
        cout << '\n';

        usleep(200000);
    }
}

int Io::printLogin()
{
    string user;
    string passwd;
    char* ch;

    for (int i = 0; i < 3; i++)
    {
        cout << "\033[2J";
        cout << "\033[20;15H";
        cout << "账号:" << flush;
        cin >> user;
        cout << "\033[22;15H";
        cout << "密码:" << flush;
        cin >> passwd;

        net.netIn("user:" + user + "+,password:" + passwd + '+');
        ch = net.netOut();
        string result(ch);
        if (result.substr(0, 5) == "Login")
        {
            cout << "\033[2J";
            cout << "\033[20;15H" << "登录成功！" << flush;
            sleep(2);
            this->tankChoice(stoi(result.substr(result.rfind(':') + 1)));
            sleep(2);
            return 0;
        }
    }

    cout << "\033[2J";
    cout << "\033[20;15H" << "登录失败！" << flush;
    exit(0);
}

void Io::tankChoice(int id)
{
    int colour;
    int modl;
    int coordinate;

    cout << "\033[2J";
    cout << "\033[5;15H" << "31:红";
    cout << "\033[7;15H" << "32:绿";
    cout << "\033[9;15H" << "33:黄";
    cout << "\033[11;15H" << "34:蓝";
    cout << "\033[13;15H" << "35:紫";
    cout << "\033[15;15H" << "37:白";

    for (int i = 0; i < 3; i++)
    {
        cout << "\033[" << i+5 << ";25H" << myTank->tank_figure[0][i][0];
        cout << "\033[" << i+9 << ";25H" << myTank->tank_figure[1][i][0];
        cout << "\033[" << i+13 << ";25H" << myTank->tank_figure[2][i][0];
    }
    cout << '\n';

    cout << "\033[20;15H" << "选择颜色:" << flush;
    cin >> colour;
    cout << "\033[22;15H" << "选择模型:" << flush;
    cin >> modl;

    cout << "\033[2J";
    this->printMap();
    cout << "\033[5;10H" << '1';
    cout << "\033[5;70H" << '2';
    cout << "\033[35;10H" << '3';
    cout << "\033[35;70H" << '4';
    cout << '\n';

    cout << "\033[42;15H";
    cout << "选择出生点:" << flush;
    cin >> coordinate;

    switch (coordinate)
    {
        case 1:
            myTank = new Tank(id, modl, colour, 10, 5);
            break;
        case 2:
            myTank = new Tank(id, modl, colour, 70, 5);
            break;
        case 3:
            myTank = new Tank(id, modl, colour, 10, 35);
            break;
        case 4:
            myTank = new Tank(id, modl, colour, 70, 35);
            break;
    }

    pthread_mutex_lock(&pthreadMutexTank);
    m_vecTank.push_back(myTank);
    pthread_mutex_unlock(&pthreadMutexTank);

    net.netIn("New:id:" + to_string(myTank->m_id) + ",model:" + to_string(myTank->m_model) + ",color:" + to_string(myTank->m_color) + ",x:" +
                      to_string(myTank->x) + ",y:" + to_string(myTank->y) + ',');
}

void *Io::netRecv(void *ptr)
{
    Io* io = (Io*) ptr;

    string buff;
    string target;
    int head;
    int end;

    while (true)
    {
        buff = io->net.netOut();

        target = buff.substr(0, 4);

        if ("Move" == target)
        {
            head = buff.find("Move:", 0);
            head += 5;
            end = buff.find(',', head);
            target = buff.substr(head, end - head);
            for (Tank* t : m_vecTank)
            {
                if (to_string(t->m_id) == target)
                {
                    if (t == io->myTank)
                    {
                        continue;
                    }
                    head = buff.find("x:", end);
                    head += 2;
                    end = buff.find(',', head);
                    target = buff.substr(head, end - head);
                    t->x = stoi(target);

                    head = buff.find("y:", end);
                    head += 2;
                    end = buff.find(',', head);
                    target = buff.substr(head, end - head);
                    t->y = stoi(target);

                    head = buff.find("d:", end);
                    head += 2;
                    end = buff.find(',', head);
                    target = buff.substr(head, end - head);
                    t->m_direction = stoi(target);
                }
            }
        }
        else if ("Fire" == target)
        {
            head = buff.find("Fire:", 0);
            head += 5;
            end = buff.find(',', head);
            target = buff.substr(head, end - head);
            for (Tank* t : m_vecTank)
            {
                if (t == io->myTank)
                {
                    continue;
                }
                if (to_string(t->m_id) == target)
                {
                    io->addShell(t);
                }
            }
        }
        else if ("Die:" == target)
        {
            head = buff.find(':', 0);
            target = buff.substr(head + 1);
            for (Tank* t : m_vecTank)
            {
                if (target == to_string(t->m_id))
                {
                    t->m_survival = false;
                }
            }
        }
        else if ("New:" == target)
        {
            head = buff.find("id:", 0);
            head += 3;
            end = buff.find(',', head);
            target = buff.substr(head, end - head);
            int id = stoi(target);

            if (id == io->myTank->m_id)
            {
                continue;
            }

            head = buff.find("model:", end);
            head += 6;
            end = buff.find(',', head);
            target = buff.substr(head, end - head);
            int model = stoi(target);

            head = buff.find("color:", end);
            head += 6;
            end = buff.find(',', head);
            target = buff.substr(head, end - head);
            int color = stoi(target);

            head = buff.find("x:", end);
            head += 2;
            end = buff.find(',', head);
            target = buff.substr(head, end -head);
            int x = stoi(target);

            head = buff.find("y:", end);
            head += 2;
            end = buff.find(',', head);
            target = buff.substr(head, end- head);
            int y = stoi(target);

            io->addTank(id, model, color, x, y);
        }
        else if ("Logo" == target)
        {
            head = buff.find(':', 0);
            target = buff.substr(head + 1);
            for (Tank* t : m_vecTank)
            {
                if (to_string(t->m_id) == target)
                {
                    auto info = find(m_vecTank.begin(), m_vecTank.end(), t);
                    pthread_mutex_lock(&pthreadMutexTank);
                    m_vecTank.erase(info);
                    pthread_mutex_unlock(&pthreadMutexTank);
                }
            }
        }
    }
}

void Io::Run()
{
    this->printLogin();

    if (!__sync_fetch_and_add(&ioNum, 1))
    {
        pthread_create(&ioId, nullptr, refresh, this);
        pthread_create(&recvId, nullptr, netRecv, this);
    }

    system("stty -icanon");
    char ch;
    bool isFire = false;
    bool isMove = false;
    int reset;

    while (true)
    {
        isMove = false;
        isFire = false;
        while (timeSig)
        {
            cin >> ch;
            switch (ch)
            {
                case 'w':
                    reset = myTank->m_direction;
                    myTank->m_direction = 0;
                    isMove = true;
                    break;
                case 's':
                    reset = myTank->m_direction;
                    myTank->m_direction = 1;
                    isMove = true;
                    break;
                case 'a':
                    reset = myTank->m_direction;
                    myTank->m_direction = 2;
                    isMove = true;
                    break;
                case 'd':
                    reset = myTank->m_direction;
                    myTank->m_direction = 3;
                    isMove = true;
                    break;
                case 'j':
                    isFire = true;
                    break;
            }
        }

        if (isFire)
        {
            pthread_mutex_lock(&pthreadMutexShell);
            m_vecShell.push_back(myTank->tankFire());
            pthread_mutex_unlock(&pthreadMutexShell);
            if (0 == net.netIn("Fire:" + to_string(myTank->m_id) + ','))
            {
                this->printDropLine();
            }
        }

        if (isMove)
        {
            myTank->tankMove();
            if (!this->collision(myTank))
            {
                myTank->m_direction = reset;
                continue;
            }
            net.netIn("Move:" + to_string(myTank->m_id) + ",x:" + to_string(myTank->x) + ",y:" + to_string(myTank->y) + ",d:" +
                              to_string(myTank->m_direction) + ',');
        }
    }
}

void Io::printDropLine()
{
    cout << "\033[2J";
    cout << "\033[20;15H" << "与服务器断开连接！" << flush;
    exit(0);
}

Io::~Io()
{
    if (!__sync_sub_and_fetch(&ioNum, 1))
    {
        pthread_cancel(ioId);
        pthread_cancel(recvId);

        pthread_mutex_destroy(&pthreadMutexTank);
        pthread_mutex_destroy(&pthreadMutexShell);
        for (Tank* t : m_vecTank)
        {
            delete t;
        }
        for (Shell* s : m_vecShell)
        {
            delete s;
        }
    }

    delete myTank;
}