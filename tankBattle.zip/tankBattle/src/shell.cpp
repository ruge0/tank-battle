#include "shell.h"

Shell::Shell(int id, int x, int y, int direction)
{
    this->info.id = id;
    this->info.x = x;
    this->info.y = y;
    this->m_direction = direction;
}

void Shell::shellMove()
{
    switch (m_direction)
    {
        case 0:
            (info.y)--;
            break;
        case 1:
            (info.y)++;
            break;
        case 2:
            (info.x) -= 2;
            break;
        case 3:
            (info.x) += 2;
            break;
    }
}

Shell::Info * Shell::getInfo()
{
    return &this->info;
}

Shell::~Shell() = default;